// Hide categories
mods.jei.category.remove('appliedenergistics2.grinder')
mods.jei.category.remove('appliedenergistics2.inscriber')

mods.jei.category.remove('minecraft.brewing')
mods.jei.category.remove('techguns.ammopress')
mods.jei.category.remove('techguns.metalpress')
mods.jei.category.remove('techguns.chemlab')
mods.jei.category.remove('techguns.fabricator')
mods.jei.category.remove('techguns.chargingstation')
mods.jei.category.remove('techguns.reactionchamber')
mods.jei.category.remove('techguns.oredrill')
mods.jei.category.remove('techguns.blastfurnace')
mods.jei.category.remove('techguns.grinder')
mods.jei.category.remove('techguns.camobench')

